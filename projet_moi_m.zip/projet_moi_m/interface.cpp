#include "interface.h"
#include "ui_interface.h"

Interface::Interface(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Interface)
{
    ui->setupUi(this);
    this->setWindowTitle("Projet Dr MOUSSE");
    verti=new QVBoxLayout;
    layout=new QFormLayout;
    layout->addRow(ui->nom,ui->inputNom);
    layout->addRow(ui->Prenom,ui->inputPrenom);
    layout->addRow(ui->Annee,ui->inputAn);
    verti->addLayout(layout);
    verti->addWidget(ui->butonOk);
    this->setLayout(verti);
    connect(ui->butonOk,SIGNAL(clicked(bool)),this,SLOT(Sauver_etu()));
}

Interface::~Interface()
{
    delete ui;
}
void Interface::Sauver_etu()
{
    if(ui->inputNom->text().isEmpty()|| ui->inputPrenom->text().isEmpty()|| ui->inputAn->text().isEmpty())
    {
        QMessageBox::critical(this,"Impossible","Veillez remplir tous les champs");
    }else
    {
        if(ui->inputAn->text().toInt()!=0)
        {
            if(ui->inputAn->text().size()==4)
            {
                fichier=new QFile("interface.txt");
                fichier->open(QIODevice::Append | QIODevice::Text);
                donne=new QString(ui->inputNom->text().toUpper()+" "+ui->inputPrenom->text()+" "+ui->inputAn->text()+"\n");
                fichier->write(donne->toLatin1(),donne->size());
                fichier->close();
                QMessageBox::information(this,"Fait","Votre etudiant a ete ajouté");
                ui->inputAn->setText("");
                ui->inputPrenom->setText("");
                ui->inputNom->setText("");
            }else
            {

                QMessageBox::warning(this,"Année ","Etes-vous de Mars ou Saturne " +ui->inputNom->text().toUpper()+"?\n Sinon une année qui se respecte sur la terre a minimum 4 chiffres ");

            }
        }
         else
        {
            QMessageBox::warning(this,"Année",ui->inputNom->text() + " "+ui->inputPrenom->text()+" mais vous dormez là !!! \n Mais réveillez-vous là putain");
        }
    }

}
