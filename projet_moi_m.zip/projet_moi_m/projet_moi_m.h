#ifndef PROJET_M_H
#define PROJET_M_H
#include<iostream>
//classe IUTiens
class IUTiens
{
    protected:
        std::string nom;
        std::string prenom;
        int AnneeNaissance;
    public:
        IUTiens();
        IUTiens(std::string name, std::string lastname, int date);
        IUTiens(const IUTiens& iut);
        std::string getNom();
         void setNom(std::string name);
        std::string getPrenom();
         void setPrenom(std::string prename);
        int getAnnee();
         void setAnnee(int annee);
         friend std::ostream& operator<<(std::ostream& os, const IUTiens& personne);
};

//class Filiere
//classe filière
class Filiere
{
    private:
        std::string CodFil;
        std::string LibFil;
    public:
        Filiere();
        Filiere(std::string nom,std::string code);
        Filiere(const Filiere& fil);
        std::string getCodFil();
        void setCodFil(std::string codefil);
        std::string getLibFil();
        void setLibFil(std::string nomfil);
        friend std::ostream& operator<<(std::ostream& os, const Filiere& personne);


};
//class enseignant
class Enseignant : public IUTiens
{
    private:
        std::string grade;
    public:
        Enseignant();
        Enseignant(std::string mongrade,std::string name, std::string lastname, int date);
        Enseignant(const Enseignant& ens);
        std::string getGrade();
        void setGrade(std::string grado);
        friend std::ostream& operator<<(std::ostream& os, const Enseignant& personne);

};

//classe Administratif
class Administratif : public IUTiens
{
    private:
        std::string poste;
    public:
        Administratif();
        //constructeur avec parametres
        Administratif(std::string monposte, std::string name, std::string lastname, int date);
        Administratif(const Administratif& admin);
        std::string getPoste();
        void setPoste(std::string monposte);
        friend std::ostream& operator<<(std::ostream& os, const Administratif& personne);
};
//classe Etudiant
class Etudiant : public IUTiens

{
    private:
        int matricule;
        Filiere filiere;
    public:
        Etudiant();
        Etudiant(int mat,Filiere fil,std::string name, std::string lastname, int date);
        Etudiant(const Etudiant& etu);
        int getMat();
        void setMat(int mat);
        Filiere getFiliere();
        void setFiliere(std::string codefil,std::string nomfil);
        friend std::ostream& operator<<(std::ostream& os, const Etudiant& personne);

};
/*-----------------------------------------------------------------------------//
fonction de tri*/

void tri(Enseignant tab[10]);
void triplus(Enseignant tab[10]);
void tribeta(Enseignant tab[10]);




#endif // PROJET_M_H
