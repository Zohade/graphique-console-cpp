#include<QCoreApplication>
#include<iostream>
#include "projet_moi_m.h"
#include "interface.h"
#include<fstream>
using namespace std;


int main(int argc, char* argv[])
{

    QApplication app(argc,argv);
    Interface moi;
    moi.show();

    Filiere ig("Informatique de gestion","IG");
    Filiere ge("Gestion des Entreprises","GE");
    Etudiant un(00001,ig,"AJAVON","Seba",1958);
    Etudiant deux(00002,ig,"AJAVON","Seba",1958);
    Etudiant trois(00003,ig,"AJAVON","Seba",1958);
    Etudiant quatre(00004,ig,"AJAVON","Seba",1958);
    Etudiant cinq(00005,ig,"AJAVON","Seba",1958);
    Etudiant six(00006,ge,"TALON","Pato",1966);
    Etudiant sept(00007,ge,"TALON","Pato",1966);
    Etudiant huit(00011,ge,"TALON","Pato",1966);
    Etudiant neuf(00012,ge,"TALON","Pato",1966);
    Etudiant dix(00010,ge,"TALON","Pato",1966);
    Etudiant tab_etu[10]={un,deux,trois,quatre,cinq,six,sept,huit,neuf,dix};

    ofstream  monflux("etudiant.txt");
    if(monflux.is_open())
    {
        for(int i=0;i<10;i++)
        {
         if(tab_etu[i].getFiliere().getCodFil()=="IG")
         {
            monflux<<tab_etu[i]<<endl;
            cout<<"Ecriture reussie\n";
          }
        }
        monflux.close();
    }




    Enseignant ens_un("maitre assistant","AJAVON","Seba",1958);
    Enseignant ens_deux("maitre assistant","Zannou","Seba",1958);
    Enseignant ens_trois("maitre assistant","Gouli","Seba",1958);
    Enseignant ens_quatre("maitre assistant","Soulou","Seba",1958);
    Enseignant ens_cinq("maitre assistant","Savon","Seba",1958);
    Enseignant ens_six("maitre assistant","Komgui","Pato",1966);
    Enseignant ens_sept("maitre assistant","Hagbe","Zato",1966);
    Enseignant ens_huit("maitre assistant","TALON","Pato",1966);
    Enseignant ens_neuf("maitre assistant","Donan","Baca",1966);
    Enseignant ens_dix("maitre assistant","TALON","Patot",1966);
    Enseignant tab[10]={ens_un,ens_deux,ens_trois,ens_quatre,ens_cinq,ens_six,ens_sept,ens_huit,ens_neuf,ens_dix};
     tribeta(tab);
    return app.exec();
}
