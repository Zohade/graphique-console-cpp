Ce que code est fait avec l'IDE Qt Creator en utilisant Qt Designer pour la partie garphique.

Il s'agit avant tout de créer 5 classes en C++ : 
	- IUTiens
	- Enseignant
	- Administratif
	- Etudiant 
	- Filière

disposant chacun des méthodes telles que les constructeurs, les setteurs et getteurs et aussi d'une méthode d'affichage en plus des attributs et des méthodes spécifiques à chaque classe.

Ensuite, on a crée 10 etudiants répartis en deux filières (GE et IG)

crée 10 enseignants
affiché la liste des enseignants par ordre alphabétique en mode console 
sauvegardé dans un fichier etudiant.txt les etudiants de la filière IG.

En mode graphique, 
on a crée avec qt designer un widget formulaire constitué d'un champ ce renseignement du nom, du prenom, et de l'année de 
naissance puis d'un bouton ok.

Lorsque l'user entre ses infos, on vérifie les infos et on sauvegarde dans un fichier interface.txt
puis affiche un messsage montrant à l'utilisateur que ses infos ont été bien enrégistrées. 

 
