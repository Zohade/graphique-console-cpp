#ifndef INTERFACE_H
#define INTERFACE_H
#include <QApplication>
#include<QFile>
#include <QWidget>
#include<QLineEdit>
#include<QMessageBox>
#include<QIcon>
#include <QFormLayout>
#include <QVBoxLayout>

namespace Ui {
class Interface;
}

class Interface : public QWidget
{
    Q_OBJECT

public:
    explicit Interface(QWidget *parent = 0);
    ~Interface();
public slots:
    void Sauver_etu();
private:
    Ui::Interface *ui;
    QFile *fichier;
    QString *donne;
    QFormLayout *layout;
    QVBoxLayout *verti;
};

#endif // INTERFACE_H
