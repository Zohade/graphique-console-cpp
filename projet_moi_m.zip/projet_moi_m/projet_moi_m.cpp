#include "projet_moi_m.h"
using namespace std;

//----------------DEBUT METHODES IUTIENS---------------------
//constructeur sans parametre
IUTiens::IUTiens()
{
    AnneeNaissance=0;
    nom="";
    prenom="";
}
//construceteur avec parametres
IUTiens::IUTiens(string name, string lastname, int date):AnneeNaissance(date),nom(name),prenom(lastname){}
//contructeur par copie
IUTiens::IUTiens(const IUTiens& iut)
{
    nom=iut.nom;
    prenom=iut.prenom;
    AnneeNaissance=iut.AnneeNaissance;
}
//geteur de nom
string IUTiens::getNom()
{
    return nom;
}
// seteur de nom
void IUTiens::setNom(string name)
{
    nom=name;
}

//geteur de prenom
string IUTiens::getPrenom()
{
    return prenom;
}
//seteur prenom
void IUTiens::setPrenom(string prename)
{
    prenom=prename;
}
//geteur de Anne
int IUTiens::getAnnee()
{
    return AnneeNaissance;
}
//seteur annee
void IUTiens::setAnnee(int annee)
{
    AnneeNaissance=annee;
}
 std::ostream& operator<<(std::ostream& cout, const IUTiens& personne)
{
     cout << "je m'appelle " << personne.nom << " " << personne.prenom<<" et je suis nee en "<<personne.AnneeNaissance;
            return cout;

}

/*----------FIN METHODES IUTIENS--------------

//-------------DEBUT METHODES FILIERE-------------------*/
//classe filière

Filiere:: Filiere():CodFil(""),LibFil(""){}
//construecteur prenant les parametres
Filiere::Filiere(string nom,string code):CodFil(code), LibFil(nom){}
//contructeur par copie
Filiere::Filiere(const Filiere& fil)
{
    CodFil=fil.CodFil;
    LibFil=fil.LibFil;
}

//geteur de Codfil
string Filiere:: getCodFil()
{
    return CodFil;
}
// seteur de Codfil
void Filiere:: setCodFil(string codefil)
{
    CodFil=codefil;
}
//geteur de Libfil
string Filiere:: getLibFil()
{
    return LibFil;
}
// seteur de Libfil
void  Filiere::setLibFil(string nomfil)
{
    LibFil=nomfil;
}
std::ostream& operator<<(std::ostream& cout, const Filiere& personne)
{
    cout<<personne.LibFil<<" ("<<personne.CodFil<<")"<<endl;
    return cout;
}


/*-------------FIN DES METHODES DE FILIERE------------------------

//-------------DEBUT METHODES CLASSE ENSEIGNANT--------------------*/

//constructeur sans parametre
Enseignant::Enseignant():grade(""){}
//construceteur avec parametres
Enseignant::Enseignant(string mongrade,string name, string lastname, int date):IUTiens(name,lastname,date)
{
    grade=mongrade;
}
//contructeur par copie
Enseignant::Enseignant(const Enseignant& ens)
{
    grade=ens.grade;
    AnneeNaissance=ens.AnneeNaissance;
    nom=ens.nom;
    prenom=ens.prenom;
}

//geteur grade
string Enseignant::getGrade()
{
    return grade;
}
//seteur grade
void Enseignant::setGrade(string grado)
{
    grade=grado;
}
std::ostream& operator<<(std::ostream& cout, const Enseignant & personne)
{
    cout<<"Je m'appelle "<<personne.nom<<" "<<personne.prenom<<" nee en :"<<personne.AnneeNaissance<<" et mon grade est : "<<personne.grade;
    return cout;
}
/*-------------FIN DES METHODES DE ENSEIGNANT------------------------

//-------------DEBUT METHODES CLASSE AMINISTRATIF--------------------*/

//constructeur sans parametre
Administratif ::Administratif():poste(""){}
//constructeur avec parametres
Administratif ::Administratif(string monposte, string name, string lastname, int date):IUTiens(name,lastname,date)
{
    poste=monposte;
}
//contructeur par copie
Administratif ::Administratif(const Administratif& admin)
{
    poste=admin.poste;
    AnneeNaissance=admin.AnneeNaissance;
    nom=admin.nom;
    prenom=admin.prenom;
}
//geteur de poste
string Administratif ::getPoste()
{
    return poste;
}
//seteur de poste
void Administratif ::setPoste(string monposte)
{
    poste=monposte;
}
std::ostream& operator<<(std::ostream& cout, const Administratif & personne)
{
    cout<<"Je m'appelle "<<personne.nom<<" "<<personne.prenom<<" nee en :"<<personne.AnneeNaissance<<" et je suis le : "<<personne.poste;
    return cout;
}
/*-------------FIN DES METHODES DE AMINISTRATIF------------------------

//-------------DEBUT METHODES CLASSE ETUDIANT--------------------*/
    Etudiant::Etudiant():matricule(0),filiere(){}
    Etudiant::Etudiant(int mat,Filiere fil,string name, string lastname, int date):IUTiens(name,lastname,date)
    {
        matricule=mat;
        filiere=fil;
    }
    //contructeur par copie
    Etudiant::Etudiant(const Etudiant& etu)
    {
        matricule=etu.matricule;
        AnneeNaissance=etu.AnneeNaissance;
        nom=etu.nom;
        prenom=etu.prenom;
        filiere=etu.filiere;
    }

    int Etudiant::getMat()
    {
        return matricule;
    }
    void Etudiant::setMat(int mat)
    {
        matricule=mat;
    }
    Filiere Etudiant::getFiliere()
    {
        return filiere;
    }
    void Etudiant::setFiliere(string codefil,string nomfil)
    {
        filiere.setCodFil(codefil);
        filiere.setLibFil(nomfil);

    }
     std::ostream& operator<<(std::ostream& cout, const Etudiant& personne)
    {
         cout<<"Je m'appelle "<<personne.nom<<" "<<personne.prenom<<". Je suis nee en : "<<personne.AnneeNaissance<<". Je suis un etudiant ayant pour matricule : "<<personne.matricule<<" et ma filiere est : ";
         cout<<personne.filiere;
         return cout;
    }

    /*-------------FIN DES METHODES DE ETUDIANT------------------------

    //------------- --------------------*/

     /*void trialpha(Enseignant tab[10])
     {

         Enseignant min;
         for(int k=0; k<9;k++)
         {
             for(int j=0; j<10;j++)
             {
                 if(tab[j].getNom()>tab[j+1].getNom())
                 {
                     min=tab[j+1];
                     tab[j+1]=tab[j];
                     tab[j]=min;

                 }
                 if(tab[j].getNom()==tab[j+1].getNom())
                 {


                     if(tab[j].getPrenom()>tab[j+1].getPrenom()){
                         min=tab[j+1];
                         tab[j+1]=tab[j];
                         tab[j]=min;
                     }

                 }
             }

         }

         cout<<"Affichages des enseignants dans l'odre aphalbetique\n";
         for(int l=0;l<10;l++)
         {
             cout<<l+1<<"e -> "<<tab[l]<<endl;
         }

     }

   /*---------------------------------------------------------------------
    *another tri fonction--------------------------
     void triplus(Enseignant tab[10])
     {
         int i=0, j;
         bool perm=true;
         Enseignant min;
         for(i<10;i++;)
         {
             while(perm && i<10)
             {
                 perm=false;
                 j=0;
                 while(j<9)
                 {
                     if(tab[j].getNom()>tab[j+1].getNom())
                     {
                         perm=true;
                         min.getNom()=tab[j].getNom();
                         tab[j].getNom()=tab[j+1].getNom();
                         tab[j+1].getNom()=tab[j].getNom();
                     }
                     j++;

                 }
                 i++;
             }
         }
         cout<<"Affichage des Enseignants dans l'ordre alphabetique\n";
         for(int i=0;i<10;)
         {
             cout<<tab[i++]<<endl;
         }

     }

/*-------------------------------------------------------------------------
 *tri beta
 */
void tribeta(Enseignant tab[10])
{
    for(int i=0; i<9;i++)
    {
        for(int j=i+1; j<10;j++)
        {
            if(tab[i].getNom()>tab[j].getNom() || (tab[i].getNom()==tab[j].getNom() && tab[i].getPrenom()>tab[j].getPrenom()))
            {
                Enseignant min=tab[i];
                tab[i]=tab[j];
                tab[j]=min;
            }

        }
    }
    cout<<"Affichage des Enseignants dans l'ordre alphabetique\n";
    for(int i=0;i<10;)
    {
        cout<<tab[i++]<<endl;
    }
}


